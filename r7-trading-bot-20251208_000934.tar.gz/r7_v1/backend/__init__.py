# Backend API - FastAPI com autenticação JWT
