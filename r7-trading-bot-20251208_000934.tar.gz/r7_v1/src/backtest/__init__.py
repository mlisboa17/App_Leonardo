"""Módulo de Backtesting"""
# Implementar futuramente com backtrader ou Zipline
