"""Pacote principal do KriptoScan"""
