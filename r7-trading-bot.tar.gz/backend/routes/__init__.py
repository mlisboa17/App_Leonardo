# Routes package
from . import auth_routes, dashboard_routes, config_routes, actions_routes, bot_control_routes
